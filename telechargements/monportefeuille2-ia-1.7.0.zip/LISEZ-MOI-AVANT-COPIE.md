# À lire avant de copier — IA 1.7.0 « analyse long terme »

Ce dossier contient **exactement les 12 fichiers** qui font passer l'IA de
« elle cite le corpus » à « elle l'analyse », avec l'horizon retraite 2055 et la
recherche extérieure.

Les dossiers sont les mêmes que dans le dépôt : un fichier va toujours dans le
dossier du même nom. Vous pouvez donc faire glisser les dossiers entiers dans
GitHub.

---

## Méthode A — la plus simple : fusionner la pull request (2 clics)

Tout est déjà sur GitHub, dans la pull request **#2** :

```
https://github.com/flaviensaillard/MonPortefeuille2/pull/2
```

1. Ouvrez ce lien.
2. Cliquez sur **« Merge pull request »**, puis **« Confirm merge »**.

C'est fini — inutile d'utiliser le zip. Vous pouvez ensuite passer à l'étape 1 du
guide (`GUIDE-IA-ANALYSE-LONG-TERME.md`, section 3) pour coller le nouveau code
dans Cloudflare.

## Méthode B — copier les fichiers un par un (si vous préférez tout voir)

Pour chaque fichier ci-dessous : ouvrez-le dans ce dossier, copiez son contenu,
et collez-le dans le fichier du même nom sur GitHub (bouton crayon ✏️ → tout
sélectionner → coller → **Commit changes**).

Pour le fichier **nouveau** (`GUIDE-IA-ANALYSE-LONG-TERME.md`) : dans le dépôt,
bouton **« Add file » → « Create new file »**, tapez le nom exact, collez, puis
**Commit changes**.

---

## Les 12 fichiers, et à quoi ils servent

| # | Fichier | Dossier dans GitHub | Obligatoire ? |
|---|---|---|---|
| 1 | `GUIDE-IA-ANALYSE-LONG-TERME.md` | racine | oui — **c'est le guide pas à pas** (nouveau fichier) |
| 2 | `ia/worker/src/index.js` | `ia/worker/src` | oui — **le service** : c'est ce code que vous collez chez Cloudflare |
| 3 | `ia/REGLES.md` | `ia` | oui — les règles en clair, l'autre face du prompt |
| 4 | `ia/tests/test_worker.mjs` | `ia/tests` | oui — les tests qui vérifient les tournures imposées |
| 5 | `ia/ARCHITECTURE.md` | `ia` | non — documentation |
| 6 | `ia/LISEZ-MOI.md` | `ia` | non — documentation |
| 7 | `ia/worker/wrangler.toml` | `ia/worker` | non — utile seulement en ligne de commande (`wrangler deploy`) |
| 8 | `pages/5_IA.py` | `pages` | oui — horizon + case « Autoriser la recherche extérieure » + sources `[E…]` (Streamlit) |
| 9 | `ia/android/ia.js` | `ia/android` | non — pour l'APK : bouton « ✓ Internet », horizon, sources extérieures |
| 10 | `app/src/main/assets/www/js/ia.js` | `app/src/main/assets/www/js` | non — **copie identique** du n° 9, dans l'application |
| 11 | `tests/test_js.js` | `tests` | non — tests du moteur JavaScript |
| 12 | `README.md` | racine | non — renvoie vers le nouveau guide |

Deux remarques :

- les fichiers **9 et 10 sont identiques au caractère près** : si vous n'en
  copiez qu'un, copiez le 10 (celui qui est embarqué dans l'APK) ;
- le **n° 2 doit rester un fichier unique** : ne le découpez pas, la méthode
  « copier-coller dans le tableau de bord Cloudflare » ne fonctionnerait plus.

---

## Après la copie (5 minutes)

1. Coller `ia/worker/src/index.js` dans Cloudflare :
   `dash.cloudflare.com` → **Compute (Workers)** → service **`universite-epargne`**
   → **Edit code** → tout effacer → coller → **Deploy**.
2. Vérifier : ouvrez
   `https://universite-epargne.VOTRE-SOUS-DOMAINE.workers.dev/sante`
   Vous devez voir **`"version":"1.7.0"`** et un bloc `"horizon"` avec
   `"anneeDepartRetraite":2055`.
3. Poser vos trois questions et comparer avec la section 4 du guide.

Aucune clé à créer, aucune variable à saisir : l'horizon 2055 est dans le code,
et la recherche extérieure utilise DuckDuckGo puis Wikipédia, qui ne demandent
ni compte ni clé.

---

## Si vous ne copiez qu'une seule chose

**Le fichier n° 2** (`ia/worker/src/index.js`), collé chez Cloudflare. C'est lui
qui contient les tournures imposées, l'horizon 2055 et la recherche extérieure.
Le reste améliore le confort (affichage des sources extérieures, interrupteur
Internet) ou la documentation.
