"""Le direct doit être comparé au snapshot nocturne, jamais à l'avant-dernier."""
import datetime as dt

import pandas as pd
import pytest

from core import session as S


class DateFixe(dt.date):
    @classmethod
    def today(cls):
        return cls(2026, 10, 7)


@pytest.fixture
def contexte(monkeypatch):
    monkeypatch.setattr(S.dt, "date", DateFixe)
    monkeypatch.setattr(S.db, "lire", lambda table: pd.DataFrame())
    ctx = S.Contexte()
    ctx.taux_eur_usd = 1.125
    ctx.total_investi_eur = 72529.0
    ctx.total_investi_usd = 72529.0 * ctx.taux_eur_usd
    ctx.patrimoine_total_eur = 82529.0
    ctx.patrimoine_total_usd = 82529.0 * ctx.taux_eur_usd
    ctx.total_precaution_eur = 10000.0
    ctx.total_precaution_usd = 11250.0
    ctx.snapshots = pd.DataFrame([
        {"Date": pd.Timestamp("2026-10-06"), "patrimoine_investi_eur": 70084.0,
         "patrimoine_total_eur": 80084.0, "equivalent_or_oz": 70084.0 * 1.125 / 4000, "cours_or_usd": 4000.0},
        {"Date": pd.Timestamp("2026-10-07"), "patrimoine_investi_eur": 72226.23,
         "patrimoine_total_eur": 82226.23, "precaution_eur": 10000.0,
         "equivalent_or_oz": 72226.23 * 1.125 / 4000, "cours_or_usd": 4000.0},
    ])
    return ctx


@pytest.mark.parametrize("perimetre,base", [("Portefeuille investi", 72226.23), ("Patrimoine total", 82226.23)])
def test_snapshot_du_7_octobre_conserve(contexte, perimetre, base):
    originaux = contexte.snapshots.copy(deep=True)
    S._enrichir_historiques_usd(contexte)
    pd.testing.assert_frame_equal(originaux, contexte.snapshots.iloc[:2][originaux.columns])
    p = S.progression_periode(contexte, perimetre=perimetre)
    assert p["v_debut_usd"] == pytest.approx(base * 1.125, abs=0.01)
    assert p["gain_marche_eur"] == pytest.approx(302.77, abs=0.01)
    assert p["twr_per"] == pytest.approx(302.77 / base, abs=1e-7)
    assert p["apports_periode_usd"] == 0
    assert "dernier enregistrement" in p["label_periode"]
    assert len(contexte.snapshots) == 3


def test_un_seul_snapshot_suffit_avec_le_direct(contexte):
    contexte.snapshots = contexte.snapshots.tail(1).reset_index(drop=True)
    S._enrichir_historiques_usd(contexte)
    p = S.progression_periode(contexte)
    assert not p["vide"]
    assert p["gain_marche_eur"] == pytest.approx(302.77, abs=0.01)


def test_snapshot_recent_prioritaire_sur_projections(contexte, monkeypatch):
    projections = pd.DataFrame([
        {"Date": "06/10/2026", "Actifs Stratégiques": 70084 * 1.125, "Capital investi": 60000},
        {"Date": "07/10/2026", "Actifs Stratégiques": 70000 * 1.125, "Capital investi": 60000},
    ])
    monkeypatch.setattr(S.db, "lire", lambda table: projections if table == "Projections" else pd.DataFrame())
    S._enrichir_historiques_usd(contexte)
    p = S.progression_periode(contexte)
    assert p["gain_marche_eur"] == pytest.approx(302.77, abs=0.01)
    assert contexte.snapshots["capital_investi_usd"].tolist() == [60000, 60000, 60000]


def test_snapshot_ancien_direct_date_du_jour_et_apport_neutralise(contexte):
    contexte.snapshots = contexte.snapshots.tail(1).reset_index(drop=True)
    contexte.snapshots["Date"] = pd.Timestamp("2026-10-05")
    contexte.apports = pd.DataFrame([{"date": "2026-10-06", "sens": "apport", "montant_eur": 100, "montant_usd": 112.5}])
    S._enrichir_historiques_usd(contexte)
    p = S.progression_periode(contexte)
    assert contexte.snapshots["Date"].iloc[-1] == pd.Timestamp("2026-10-07")
    assert p["apports_periode_usd"] == 112.5
    assert p["gain_marche_eur"] == pytest.approx(202.77, abs=0.01)


def test_apport_du_jour_pas_compte_deux_fois(contexte):
    contexte.apports = pd.DataFrame([{"date": "2026-10-07", "sens": "apport", "montant_eur": 100, "montant_usd": 112.5}])
    S._enrichir_historiques_usd(contexte)
    _, _, flux = S.serie_performance(contexte)
    assert flux == [0, 112.5, 0]


def test_conversion_usd_historique_et_pas_taux_du_jour(contexte):
    contexte.snapshots = contexte.snapshots.tail(1).reset_index(drop=True)
    contexte.snapshots["equivalent_or_oz"] = 72226.23 * 1.12 / 4000
    S._enrichir_historiques_usd(contexte)
    p = S.progression_periode(contexte)
    assert p["v_debut_usd"] == pytest.approx(72226.23 * 1.12, abs=0.01)
    assert p["v_fin_usd"] == pytest.approx(72529 * 1.125, abs=0.01)
    # Le rendement USD inclut le change, il n'est pas le ratio brut en EUR.
    assert p["twr_per"] == pytest.approx((72529 * 1.125) / (72226.23 * 1.12) - 1, abs=1e-7)


def test_sans_cours_live_ne_pas_effacer_le_snapshot(contexte):
    contexte.total_investi_usd = 0
    S._enrichir_historiques_usd(contexte)
    assert len(contexte.snapshots) == 2
    assert contexte.snapshots.iloc[-1]["patrimoine_investi_eur"] == 72226.23


def test_pas_de_doublon_live_apres_reenrichissement(contexte):
    S._enrichir_historiques_usd(contexte)
    S._enrichir_historiques_usd(contexte)
    assert len(contexte.snapshots) == 3
    assert S.progression_periode(contexte)["gain_marche_eur"] == pytest.approx(302.77, abs=0.01)


def test_un_seul_snapshot_sans_live_ne_plante_pas(contexte):
    contexte.snapshots = contexte.snapshots.tail(1).reset_index(drop=True)
    contexte.total_investi_usd = 0
    S._enrichir_historiques_usd(contexte)
    assert S.progression_periode(contexte)["gain_marche_usd"] == 0


def test_snapshot_sans_or_utilise_le_repli_de_change(contexte):
    contexte.snapshots = contexte.snapshots.drop(columns=["equivalent_or_oz", "cours_or_usd"])
    S._enrichir_historiques_usd(contexte)
    assert S.progression_periode(contexte)["gain_marche_eur"] == pytest.approx(302.77, abs=0.01)


def test_ordre_de_lecture_supabase_sans_importance(contexte):
    contexte.snapshots = contexte.snapshots.iloc[::-1]
    S._enrichir_historiques_usd(contexte)
    assert S.progression_periode(contexte)["gain_marche_eur"] == pytest.approx(302.77, abs=0.01)
