"""Contexte applicatif : charge les données une fois, calcule tout.

CORRECTION PAR RAPPORT À LA V1
------------------------------
La v1 rechargeait et recalculait à chaque rendu de page, et le robot nocturne
écrivait des colonnes TWR dans Supabase depuis un script séparé (`calc_perf.py`).
Deux sources de vérité pour la même grandeur, désynchronisables.

Ici, le TWR est calculé à la demande depuis les snapshots, jamais stocké. Le
robot ne fait qu'écrire des snapshots bruts.
"""

from __future__ import annotations

import datetime as dt
import logging
from dataclasses import dataclass, field

import pandas as pd
import streamlit as st

from . import db, fx, metrics, prices
from .models import (
    Perimetre,
    POCHES_PAR_CLE,
    allocation_par_defaut,
    appliquer_allocation_personnalisee,
    verifier_allocation_cible,
)
from .portfolio import (
    Actif,
    agreger_par_poche,
    calculer_positions,
    charger_transactions,
    flux_titres_internes,
    valoriser,
)
from .rebalance import diagnostiquer

log = logging.getLogger(__name__)


@dataclass
class Contexte:
    """Tout ce dont les pages ont besoin, calculé une fois."""

    transactions: list = field(default_factory=list)
    positions: dict = field(default_factory=dict)
    actifs: list[Actif] = field(default_factory=list)
    etats: dict = field(default_factory=dict)
    snapshots: pd.DataFrame = field(default_factory=pd.DataFrame)
    apports: pd.DataFrame = field(default_factory=pd.DataFrame)
    inflation: pd.DataFrame = field(default_factory=pd.DataFrame)

    total_investi_eur: float = 0.0
    total_precaution_eur: float = 0.0
    total_courant_eur: float = 0.0
    patrimoine_total_eur: float = 0.0

    total_investi_usd: float = 0.0
    total_precaution_usd: float = 0.0
    total_courant_usd: float = 0.0
    patrimoine_total_usd: float = 0.0
    taux_eur_usd: float = 1.125

    cours_or: float | None = None
    equivalent_or_oz: float | None = None

    echecs_cours: list[str] = field(default_factory=list)
    echecs_fx: list[str] = field(default_factory=list)
    tables_absentes: list[str] = field(default_factory=list)
    erreurs: list[str] = field(default_factory=list)
    anomalies_transactions: list[str] = field(default_factory=list)
    allocation_cfg: dict = field(default_factory=allocation_par_defaut)
    etat_allocation: dict = field(default_factory=verifier_allocation_cible)
    variations_actifs: dict[str, float] = field(default_factory=dict)
    # Date du dernier import, lue dans `cree_le`. Sert a voir d'un coup
    # d'oeil si l'application regarde des donnees fraiches : un serveur qui
    # tourne sur une vieille version du code affiche une date anterieure au
    # dernier import, et le bandeau d'anomalie survit a sa correction.
    importe_le: str | None = None

    @property
    def ecarts(self):
        return diagnostiquer(
            self.etats,
            self.total_investi_eur + self.total_courant_eur,
            self.total_investi_usd + self.total_courant_usd,
        )

    @property
    def besoins_reequilibrage(self):
        return [e for e in self.ecarts if e.hors_bande]


def _inflation_par_annee(df: pd.DataFrame) -> dict[int, float]:
    """Inflation annuelle, en fraction (2 % -> 0.02).

    DÉFAUT CORRIGÉ. Cette fonction faisait `if df.empty or "Annee" not in
    df.columns: return {}`. Elle confondait « pas de données » et « données que
    je ne sais pas lire » : `db.inflation()` rendait `annee`/`inflation` en
    minuscules, la colonne `Annee` était donc absente, et la fonction retournait
    un dictionnaire vide — pour toujours, et sans le dire.

    C'était le pire des deux mondes : la performance réelle de chaque année
    s'affichait « non calculable » alors que les chiffres étaient en base.

    Maintenant : une table ABSENTE ou VIDE reste silencieuse (au démarrage,
    c'est normal) ; une table PLEINE dont aucune ligne n'est exploitable lève.
    """
    if df is None or df.empty:
        return {}

    if "Annee" not in df.columns or "Inflation" not in df.columns:
        # `db.inflation()` fait le pont de noms et leve deja si c'est
        # impossible. Si on arrive ici, c'est que la table a ete lue par un
        # autre chemin — un test, un robot. On le dit.
        raise ValueError(
            f"Table d'inflation illisible : colonnes {list(df.columns)}. "
            "Attendu : Annee et Inflation. La performance reelle ne peut pas "
            "etre calculee — mieux vaut une erreur visible qu'un zero."
        )

    out: dict[int, float] = {}
    lignes_ignorees = 0
    for _, r in df.iterrows():
        try:
            out[int(r["Annee"])] = float(r["Inflation"]) / 100.0
        except (TypeError, ValueError):
            lignes_ignorees += 1
            continue

    if not out and lignes_ignorees:
        raise ValueError(
            f"{lignes_ignorees} ligne(s) d'inflation presentes, aucune "
            "exploitable. Les colonnes Annee/Inflation sont peut-etre "
            "inversees — verifiez la table pf2_inflation."
        )
    return out


def _date_dernier_import(df) -> str | None:
    """Date la plus recente de la colonne `cree_le`, ou None si absente.

    Volontairement tolerant : une table sans `cree_le` (ou vide) ne doit pas
    empecher l'application de demarrer.
    """
    try:
        if df is None or df.empty or "cree_le" not in getattr(df, "columns", []):
            return None
        valeurs = pd.to_datetime(df["cree_le"], errors="coerce").dropna()
        if valeurs.empty:
            return None
        return str(valeurs.max())
    except Exception:
        return None



# ---------------------------------------------------------------------------
# Le TWR du portefeuille — une seule implementation, trois appelants
# ---------------------------------------------------------------------------
# `derniere_valeur / premiere_valeur - 1` a ete ecrit a trois endroits :
# `Contexte.perf_globale_pct` (affiche sur la page d'accueil), le tableau
# annuel de `pages/5_Performance.py`, et le CAGR historique qui preremplit le
# scenario A de `pages/6_Retraite.py`. Les trois comptaient les VERSEMENTS
# comme du rendement.
#
# Sur le portefeuille reel — 10 905 EUR en avril 2023, 79 394 EUR en octobre
# 2026, alimente chaque mois — le calcul donnait +628 % cumule, soit **76 % par
# an** apres annualisation. C'est ce chiffre qui preremplissait la projection de
# retraite. La realite est un TWR de l'ordre de 10 a 15 %.
#
# Une seule fonction, testee, et plus aucun appelant ne peut reintroduire le
# defaut sans faire echouer `tests/test_twr_portefeuille.py`.


def flux_par_date(apports: pd.DataFrame, colonne: str = "montant_eur") -> dict:
    """Apports et retraits, dates par jour.

    `apports` doit avoir les colonnes `date`, `sens`, et `colonne`
    (`montant_usd` ou `montant_eur`). Retourne `{date: montant signe}`, un
    apport etant positif.

    Le montant est pris en VALEUR ABSOLUE (comme la table `pf2_apports`, qui
    stocke des montants positifs) : le signe vient uniquement de `sens`. Un
    montant deja signe negativement reste donc un retrait, au lieu de devenir
    un apport et de gonfler la performance.
    """
    if apports is None or apports.empty:
        return {}
    col = colonne if colonne in apports.columns else "montant_eur"
    if not {"date", "sens", col} <= set(apports.columns):
        return {}
    dates = pd.to_datetime(apports["date"], errors="coerce")
    signes = apports["sens"].astype(str).str.strip().str.lower().map(
        {"apport": 1.0, "ajout": 1.0, "retrait": -1.0}
    )
    montants = pd.to_numeric(apports[col], errors="coerce")
    sortie: dict = {}
    for d, s, m in zip(dates, signes, montants):
        if pd.isna(d) or s is None or pd.isna(m):
            continue
        jour = d.date()
        sortie[jour] = sortie.get(jour, 0.0) + s * abs(float(m))
    return sortie


def flux_instruments_final_usd(ctx: "Contexte") -> float:
    """Achats et ventes de titres à imputer à la dernière période.

    Payer des titres avec des liquidités ne change pas la richesse : c'est un
    transfert du périmètre « courant » vers le périmètre « investi ». Compté
    comme un gain de marché, il gonfle la performance du montant de l'opération
    — l'artefact constaté le 07/10/2026 (68 FLXC.L, 1 943,91 $, saisis après le
    snapshot du soir : +2,85 % affichés au lieu de -0,38 %).

    Le test décisif n'est pas la date de l'opération mais son ENREGISTREMENT :
    une opération saisie après le snapshot ne peut pas y figurer, même si elle
    porte la même date. L'horodatage `cree_le` le dit exactement ; à défaut
    (lignes importées de la v1), on retient les opérations postérieures à la
    date de la référence — jamais celles du même jour, pour ne pas compter deux
    fois un achat déjà présent dans le snapshot.

    Retourne un montant signé en dollars : un achat est positif (il entre dans
    le périmètre investi), une vente négative.
    """
    transactions = getattr(ctx, "transactions", None) or []
    snaps = getattr(ctx, "snapshots", None)
    if not transactions or snaps is None or getattr(snaps, "empty", True):
        return 0.0
    if "Date" not in getattr(snaps, "columns", []):
        return 0.0

    reference = snaps[~snaps["_live"].eq(True)] if "_live" in snaps.columns else snaps
    if reference is None or reference.empty:
        return 0.0
    dates_ref = _parser_dates(reference["Date"]).dropna()
    if dates_ref.empty:
        return 0.0
    derniere = dates_ref.max().date()
    dernieres = reference.loc[dates_ref == dates_ref.max()]
    cree_ref = None
    if "cree_le" in dernieres.columns and not dernieres.empty:
        brut = dernieres.iloc[-1].get("cree_le")
        if pd.notna(brut):
            cree_ref = pd.to_datetime(brut, errors="coerce", utc=True)

    total = 0.0
    for t in transactions:
        montant = abs(float(getattr(t, "montant_usd", 0.0) or 0.0))
        if montant <= 0:
            continue
        cree = None
        brut_t = getattr(t, "cree_le", None)
        if brut_t:
            cree = pd.to_datetime(brut_t, errors="coerce", utc=True)
        if cree is not None and pd.notna(cree) and cree_ref is not None and pd.notna(cree_ref):
            apres = cree > cree_ref
        else:
            jour = getattr(t, "date", None)
            apres = bool(jour and jour > derniere)
        if not apres:
            continue
        signe = 1.0 if getattr(t, "est_achat", False) else -1.0
        total += signe * montant
    return round(total, 2)


def serie_performance(
    ctx: "Contexte",
) -> tuple[pd.DataFrame, list[float], list[float]]:
    """Série propre `(snapshots, valeurs, flux)` pour le TWR et les diagnostics.

    CONVENTION DE L'UTILISATEUR : tout est compté en DOLLARS ($).
    - Si `patrimoine_investi_usd` est présent dans `ctx.snapshots`, c'est lui
      qui est utilisé (série USD de `Projections` + valorisation USD du jour).
    - Si `capital_investi_usd` est présent (la colonne `Capital investi` de
      `Projections`), le flux de chaque sous-période `[i-1, i]` est
      `capital_investi_usd[i] - capital_investi_usd[i-1]` — exactement la
      définition de `recalculer_toute_la_base_projections` dans la v1, qui
      reproduit au centième de point les performances Swissquote / v1
      (2023 : +9,33 %, 2024 : +15,21 %, 2025 : +13,92 %, 2026 : +4,1 % / +4,47 %).
    - Pour toute période postérieure à `Projections` (ou dans les jeux de tests
      unitaires qui ne fournissent que `patrimoine_investi_eur`), on retombe sur
      `metrics.flux_par_periode` appliqué à `ctx.apports`.
    """
    snaps = ctx.snapshots
    if snaps is None or snaps.empty or "Date" not in snaps.columns:
        return pd.DataFrame(), [], []

    use_usd = (
        "patrimoine_investi_usd" in snaps.columns
        and pd.to_numeric(snaps["patrimoine_investi_usd"], errors="coerce").gt(0).sum() >= 2
    )
    col_val = "patrimoine_investi_usd" if use_usd else "patrimoine_investi_eur"
    if col_val not in snaps.columns:
        return pd.DataFrame(), [], []

    df = snaps.copy()
    df["Date"] = _parser_dates(df["Date"])
    df[col_val] = pd.to_numeric(df[col_val], errors="coerce")
    df = df.dropna(subset=["Date", col_val])
    df["_live"] = df.get("_live", pd.Series(False, index=df.index)).eq(True)
    df = df[df[col_val] > 0].sort_values(["Date", "_live"], kind="stable").reset_index(drop=True)
    if len(df) < 2:
        return df, df[col_val].astype(float).tolist(), [0.0] * len(df)

    dates_l = [d.date() for d in df["Date"]]
    valeurs = df[col_val].astype(float).tolist()

    col_ap = "montant_usd" if (use_usd and ctx.apports is not None and "montant_usd" in getattr(ctx.apports, "columns", [])) else "montant_eur"
    flux_ap = metrics.flux_par_periode(dates_l, flux_par_date(ctx.apports, col_ap))

    if use_usd and "capital_investi_usd" in df.columns:
        # `take_snapshot.py` (v1) écrit parfois `Capital investi = 0` lorsque la
        # dernière ligne renvoyée par Supabase dans `Historique` a
        # `Total_Apports_nets = NULL` (ex. le 02/10/2026). Un capital investi
        # cumulé <= 0 sur un portefeuille actif est une valeur manquante : on
        # propage alors le dernier capital connu augmenté des apports de la période.
        cap = pd.to_numeric(df["capital_investi_usd"], errors="coerce")
        cap = cap.where(cap > 0)
        flux: list[float] = [0.0]
        cap_reconstruit: list[float | None] = [
            float(cap.iloc[0]) if pd.notna(cap.iloc[0]) else None
        ]
        for i in range(1, len(df)):
            prev_c = cap_reconstruit[-1]
            if pd.notna(cap.iloc[i]) and prev_c is not None:
                flux.append(float(cap.iloc[i] - prev_c))
                cap_reconstruit.append(float(cap.iloc[i]))
            else:
                f_i = float(flux_ap[i])
                flux.append(f_i)
                cap_reconstruit.append(
                    round(prev_c + f_i, 2) if prev_c is not None else None
                )
        df["capital_investi_usd"] = cap_reconstruit
    else:
        flux = flux_ap

    return df, valeurs, flux


def _ajouter_flux_instruments(flux: list[float], montant_final: float) -> list[float]:
    """Impute les achats/ventes de titres à la DERNIÈRE période comparée.

    Le calcul journalier compare la référence et la valeur du moment, qui
    portent souvent la même date : aucun fenêtrage par date ne peut y placer
    l'opération. On l'ajoute donc explicitement au dernier flux.
    """
    if not flux or not montant_final:
        return flux
    sortie = [float(f) for f in flux]
    sortie[-1] = round(sortie[-1] + float(montant_final), 2)
    return sortie


def twr_portefeuille(ctx: "Contexte") -> float | None:
    """TWR depuis le premier snapshot, corrigé des apports et retraits (en $)."""
    df, valeurs, flux = serie_performance(ctx)
    if len(valeurs) < 2:
        return None
    flux = _ajouter_flux_instruments(flux, flux_instruments_final_usd(ctx))
    return metrics.twr_depuis(valeurs, flux)


def twr_annualise_portefeuille(ctx: "Contexte") -> float | None:
    """Le même TWR, annualisé sur la durée couverte par les snapshots."""
    snaps = ctx.snapshots
    if snaps is None or snaps.empty or len(snaps) < 2:
        return None
    dates = _parser_dates(snaps["Date"]).dropna()
    if len(dates) < 2:
        return None
    jours = (dates.iloc[-1] - dates.iloc[0]).days
    total = twr_portefeuille(ctx)
    if total is None or jours <= 0:
        return None
    return metrics.annualiser(total, jours)


def twr_en_or_portefeuille(ctx: "Contexte") -> float | None:
    """Performance en onces d'or depuis le premier snapshot, corrigée des apports."""
    df, valeurs, flux = serie_performance(ctx)
    if len(valeurs) < 2 or "equivalent_or_oz" not in df.columns:
        return None
    onces = pd.to_numeric(df["equivalent_or_oz"], errors="coerce")
    if onces.isna().any() or (onces <= 0).any():
        return None
    try:
        return metrics.twr_en_or(valeurs, flux, onces.astype(float).tolist())
    except ValueError:
        return None


def _parser_dates(serie) -> pd.Series:
    """Parse une colonne de dates en Timestamp, sans faire échouer l'appelant."""
    from . import dates
    try:
        return pd.to_datetime(dates.parser(serie))
    except Exception:
        return pd.to_datetime(serie, errors="coerce")


@st.cache_data(ttl=300, show_spinner=False)
def charger(rafraichir_cours: bool = False) -> Contexte:
    """Charge et calcule l'état complet. Mémoïsé 5 minutes."""
    ctx = Contexte()

    # --- Tables ---
    try:
        etat_tables = db.tables_presentes()
        ctx.tables_absentes = [t for t, present in etat_tables.items() if not present]
    except db.SecretsManquants as exc:
        ctx.erreurs.append(str(exc))
        return ctx
    except Exception as exc:
        ctx.erreurs.append(f"Connexion Supabase impossible : {exc}")
        return ctx

    if ctx.tables_absentes:
        ctx.erreurs.append(
            "Tables manquantes : " + ", ".join(ctx.tables_absentes)
            + ". Exécutez migrations/001_init.sql dans Supabase."
        )
        return ctx

    # --- Allocation cible personnalisée (actifs & poches) ---
    try:
        ctx.allocation_cfg = db.lire_allocation_personnalisee()
        appliquer_allocation_personnalisee(ctx.allocation_cfg)
        ctx.etat_allocation = verifier_allocation_cible(ctx.allocation_cfg)
    except Exception:
        ctx.allocation_cfg = allocation_par_defaut()
        ctx.etat_allocation = verifier_allocation_cible(ctx.allocation_cfg)

    # --- Transactions -> positions ---
    try:
        df_tx = db.transactions()
        ctx.importe_le = _date_dernier_import(df_tx)
        ctx.transactions = charger_transactions(df_tx)
        # Une transaction incohérente ne doit pas vider l'écran : on la consigne
        # et on continue, pour que vous voyiez le reste du portefeuille.
        anomalies: list[str] = []
        ctx.positions = calculer_positions(ctx.transactions, anomalies)
        ctx.anomalies_transactions = anomalies
    except ValueError as exc:
        ctx.erreurs.append(f"Transactions illisibles : {exc}")
        return ctx
    except Exception as exc:
        ctx.erreurs.append(f"Chargement des transactions : {exc}")
        return ctx

    # --- Valorisation ---
    try:
        ctx.actifs, ctx.echecs_cours = valoriser(ctx.positions)
    except fx.FXIndisponible as exc:
        ctx.echecs_fx.append(str(exc))

    # --- Taux EUR -> USD courant (pour l'indication en euros partout) ---
    aujourdhui_iso = dt.date.today().isoformat()
    try:
        ctx.taux_eur_usd = float(fx.taux("EUR", aujourdhui_iso, "USD"))
    except Exception:
        ctx.taux_eur_usd = 1.125
    from . import ui as _ui
    _ui.definir_taux_eur_usd(ctx.taux_eur_usd)

    # --- Liquidités hors transactions (CHF, CNY, USD de la table Donnees v1) ---
    _completer_liquidites_v1(ctx, aujourdhui_iso)

    # --- Variations de chaque actif depuis le dernier enregistrement ---
    try:
        vars_v1 = db.variations_donnees_v1() if hasattr(db, "variations_donnees_v1") else {}
    except Exception:
        vars_v1 = {}
    for a in ctx.actifs:
        v_rec = a.variation_pct
        if v_rec is None and hasattr(prices, "variation_recente"):
            v_rec = prices.variation_recente(a.ticker)
        info_v1 = vars_v1.get(a.ticker.upper(), {})
        if (v_rec is None or abs(v_rec) <= 1e-6) and info_v1:
            c_enreg = info_v1.get("cours_usd")
            if c_enreg and c_enreg > 0 and a.devise_cotation == "USD" and a.prix > 0 and abs(a.prix - c_enreg) > 1e-4:
                v_rec = (a.prix / c_enreg) - 1.0
            elif info_v1.get("var_fraction") is not None:
                v_rec = info_v1.get("var_fraction")
        a.variation_pct = v_rec if v_rec is not None else 0.0
        ctx.variations_actifs[a.ticker] = a.variation_pct

    # --- Agrégation par poche, sur le patrimoine INVESTI seulement ---
    perimetres_eur: dict[str, float] = {p.value: 0.0 for p in Perimetre}
    perimetres_usd: dict[str, float] = {p.value: 0.0 for p in Perimetre}
    for a in ctx.actifs:
        p = POCHES_PAR_CLE.get(a.poche)
        cle = p.perimetre.value if p else Perimetre.INVESTI.value
        perimetres_eur[cle] += a.valeur_eur
        perimetres_usd[cle] += getattr(a, "valeur_usd", a.valeur_eur)

    ctx.total_investi_eur = perimetres_eur[Perimetre.INVESTI.value]
    ctx.total_precaution_eur = perimetres_eur[Perimetre.PRECAUTION.value]
    ctx.total_courant_eur = perimetres_eur[Perimetre.COURANT.value]
    ctx.patrimoine_total_eur = sum(perimetres_eur.values())

    ctx.total_investi_usd = perimetres_usd[Perimetre.INVESTI.value]
    ctx.total_precaution_usd = perimetres_usd[Perimetre.PRECAUTION.value]
    ctx.total_courant_usd = perimetres_usd[Perimetre.COURANT.value]
    ctx.patrimoine_total_usd = sum(perimetres_usd.values())

    ctx.etats = agreger_par_poche(ctx.actifs, ctx.total_investi_eur, ctx.total_investi_usd)

    # --- Or : l'étalon de Gave ---
    try:
        ctx.cours_or = prices.cours_or()
        if ctx.cours_or and ctx.total_investi_usd > 0:
            ctx.equivalent_or_oz = ctx.total_investi_usd / ctx.cours_or
    except prices.CoursIndisponible:
        ctx.echecs_cours.append(prices.TICKER_OR)
    except fx.FXIndisponible:
        ctx.echecs_fx.append("EUR/USD (pour l'équivalent-or)")

    # --- Historiques (en dollars, avec l'indication en euros) ---
    try:
        ctx.snapshots = db.snapshots()
        ctx.apports = db.apports()
        ctx.inflation = db.inflation()
    except Exception as exc:
        ctx.erreurs.append(f"Chargement des historiques : {exc}")

    _enrichir_historiques_usd(ctx)

    return ctx


def _completer_liquidites_v1(ctx: Contexte, jour_iso: str) -> None:
    """Charge les réserves de cash (CHF, CNY, USD, EUR) depuis `Donnees` (v1).

    Dans la v1, les liquidités (`🏦 Cash réserve` et `💵 Cash`) étaient tenues
    directement dans la table `Donnees` et non dans `Transaction`. Si aucune
    ligne de précaution ou de compte courant n'est issue des transactions, on
    les lit dans `Donnees` pour que l'épargne de précaution (CHF, CNY) et le
    compte courant apparaissent sur le tableau de bord.
    """
    from .models import Classe
    from .portfolio import poche_de

    deja = {a.ticker for a in ctx.actifs if a.quantite > 0}
    if any(t in deja for t in ("CHF", "CNY")):
        return
    try:
        df_d = db.lire("Donnees")
    except Exception:
        return
    if df_d is None or df_d.empty or "Ticker" not in df_d.columns:
        return

    for _, r in df_d.iterrows():
        t = str(r.get("Ticker", "")).upper().strip()
        typ_r = str(r.get("Type", "") or "")
        if (t not in ("CHF", "CNY", "USD", "EUR") and "cash" not in typ_r.lower()) or t in deja:
            continue
        try:
            qte = float(str(r.get("Quantité", 0) or 0).replace(" ", "").replace(",", "."))
        except (TypeError, ValueError):
            continue
        if qte <= 0:
            continue
        try:
            t_eur = 1.0 if t == "EUR" else float(fx.taux(t, jour_iso, "EUR"))
            t_usd = 1.0 if t == "USD" else float(fx.taux(t, jour_iso, "USD"))
        except Exception:
            continue
        poche = poche_de(t)
        cle_poche = (
            poche.cle if poche
            else ("precaution" if "réserve" in typ_r.lower() else "courant")
        )
        ctx.actifs.append(Actif(
            ticker=t,
            classe=Classe.ESPECE,
            devise_cotation=t,
            poche=cle_poche,
            quantite=qte,
            prix=1.0,
            valeur_eur=qte * t_eur,
            valeur_usd=qte * t_usd,
            dernier_taux=t_eur,
            dernier_taux_usd=t_usd,
        ))


def _enrichir_historiques_usd(ctx: Contexte) -> None:
    """Attache les colonnes USD (`*_usd`) aux apports et aux snapshots.

    1. Pour `ctx.apports` : chaque ligne reçoit `montant_usd` depuis la table
       `Historique` de la v1 (`Montant $`), ou à défaut depuis
       `montant_or * cours_or` (qui vaut exactement `Montant $`), ou
       `montant_eur * taux_eur_usd`.
    2. Pour `ctx.snapshots` : les colonnes `Actifs Stratégiques`, `Total Global`
       et `Capital investi` de `Projections` (qui sont nativement en dollars
       dans la v1) alimentent `patrimoine_investi_usd`, `patrimoine_total_usd`,
       `precaution_usd` et `capital_investi_usd`. Et si le portefeuille est
       valorisé en direct aujourd'hui (`ctx.total_investi_usd > 0`), le dernier
       point en direct est ajouté séparément, sans écraser le snapshot nocturne.
    """
    from . import dates as _dates

    taux = ctx.taux_eur_usd if ctx.taux_eur_usd > 0 else 1.125

    # --- 1. Apports en USD ---
    if ctx.apports is not None and not ctx.apports.empty:
        ap = ctx.apports.copy()
        usd_par_ref: dict[str, float] = {}
        try:
            df_h = db.lire("Historique")
            if df_h is not None and not df_h.empty and "Montant $" in df_h.columns:
                for _, r in df_h.iterrows():
                    if pd.notna(r.get("id")) and pd.notna(r.get("Montant $")):
                        usd_par_ref[f"v1:id{r.get('id')}"] = abs(float(r["Montant $"]))
        except Exception:
            pass

        montants_usd: list[float] = []
        for _, r in ap.iterrows():
            ref = str(r.get("reference") or "")
            if ref.startswith("usd:"):
                try:
                    montants_usd.append(round(abs(float(ref.split(":", 1)[1])), 2))
                    continue
                except Exception:
                    pass
            if ref in usd_par_ref:
                montants_usd.append(round(usd_par_ref[ref], 2))
            elif pd.notna(r.get("montant_or")) and pd.notna(r.get("cours_or")) and float(r.get("montant_or") or 0) > 0 and float(r.get("cours_or") or 0) > 0:
                montants_usd.append(round(float(r["montant_or"]) * float(r["cours_or"]), 2))
            else:
                montants_usd.append(round(float(r.get("montant_eur") or 0.0) * taux, 2))
        ap["montant_usd"] = montants_usd
        ctx.apports = ap

    # --- 2. Snapshots en USD (depuis Projections + pf2_snapshots) ---
    df_proj = pd.DataFrame()
    try:
        df_proj = db.lire("Projections")
    except Exception:
        df_proj = pd.DataFrame()

    snaps = ctx.snapshots.copy() if (ctx.snapshots is not None and not ctx.snapshots.empty) else pd.DataFrame()
    if "_live" in snaps.columns:
        snaps = snaps[~snaps["_live"].eq(True)].drop(columns="_live")
    ctx.snapshots = snaps

    if df_proj is not None and not df_proj.empty and "Date" in df_proj.columns:
        p = df_proj.copy()
        p["_dt"] = _dates.parser(p["Date"]).dt.tz_localize(None).dt.normalize()
        p = p.dropna(subset=["_dt"]).sort_values("_dt").drop_duplicates(subset=["_dt"], keep="last")
        for c in ("Actifs Stratégiques", "Total Global", "Capital investi"):
            if c in p.columns:
                p[c] = pd.to_numeric(p[c], errors="coerce")
        p = p.dropna(subset=["Actifs Stratégiques"])
        p = p[p["Actifs Stratégiques"] > 0].reset_index(drop=True)

        # Dictionnaire d'or depuis pf2_snapshots
        or_par_date: dict = {}
        cours_or_par_date: dict = {}
        eur_inv_par_date: dict = {}
        eur_tot_par_date: dict = {}
        if not snaps.empty and "Date" in snaps.columns:
            snaps["_dt"] = _dates.parser(snaps["Date"]).dt.tz_localize(None).dt.normalize()
            for _, sr in snaps.dropna(subset=["_dt"]).iterrows():
                d_cle = sr["_dt"].date()
                if pd.notna(sr.get("equivalent_or_oz")):
                    or_par_date[d_cle] = float(sr["equivalent_or_oz"])
                if pd.notna(sr.get("cours_or_usd")):
                    cours_or_par_date[d_cle] = float(sr["cours_or_usd"])
                if pd.notna(sr.get("patrimoine_investi_eur")):
                    eur_inv_par_date[d_cle] = float(sr["patrimoine_investi_eur"])
                if pd.notna(sr.get("patrimoine_total_eur")):
                    eur_tot_par_date[d_cle] = float(sr["patrimoine_total_eur"])

        lignes_u = []
        for _, r in p.iterrows():
            d_cle = r["_dt"].date()
            inv_u = float(r["Actifs Stratégiques"])
            tot_u = float(r["Total Global"]) if pd.notna(r.get("Total Global")) else inv_u
            cap_raw = r.get("Capital investi")
            cap_u = float(cap_raw) if pd.notna(cap_raw) and float(cap_raw) > 0 else None
            inv_e = eur_inv_par_date.get(d_cle, round(inv_u / taux, 2))
            ratio_jour = (inv_u / inv_e) if inv_e > 0 else taux
            tot_e = eur_tot_par_date.get(d_cle, round(tot_u / ratio_jour, 2))
            if tot_u > inv_u and tot_e <= inv_e:
                tot_e = round(inv_e + (tot_u - inv_u) / ratio_jour, 2)
            lignes_u.append({
                "Date": pd.Timestamp(d_cle),
                "date": d_cle.isoformat(),
                "patrimoine_investi_usd": round(inv_u, 2),
                "patrimoine_total_usd": round(tot_u, 2),
                "precaution_usd": round(max(tot_u - inv_u, 0.0), 2),
                "courant_usd": 0.0,
                "capital_investi_usd": round(cap_u, 2) if cap_u is not None else None,
                "patrimoine_investi_eur": round(inv_e, 2),
                "patrimoine_total_eur": round(tot_e, 2),
                "precaution_eur": round(max(tot_e - inv_e, 0.0), 2),
                "courant_eur": 0.0,
                "cours_or_usd": cours_or_par_date.get(d_cle),
                "equivalent_or_oz": or_par_date.get(d_cle),
            })

        # Ajouter les éventuels snapshots de pf2_snapshots postérieurs à Projections
        max_proj = p["_dt"].max().date() if not p.empty else dt.date.min
        if not snaps.empty and "_dt" in snaps.columns:
            apres = snaps[snaps["_dt"].dt.date > max_proj].sort_values("_dt")
            for _, sr in apres.iterrows():
                d_cle = sr["_dt"].date()
                inv_e = float(sr.get("patrimoine_investi_eur") or 0.0)
                tot_e = float(sr.get("patrimoine_total_eur") or inv_e)
                oz = sr.get("equivalent_or_oz")
                co = sr.get("cours_or_usd")
                if pd.notna(oz) and pd.notna(co) and float(oz) > 0 and float(co) > 0:
                    inv_u = float(oz) * float(co)
                    ratio = inv_u / inv_e if inv_e > 0 else taux
                    tot_u = tot_e * ratio
                else:
                    inv_u = inv_e * taux
                    tot_u = tot_e * taux
                if tot_e <= inv_e and ctx.total_precaution_eur > 0:
                    tot_e = round(inv_e + ctx.total_precaution_eur + ctx.total_courant_eur, 2)
                    tot_u = round(inv_u + ctx.total_precaution_usd + ctx.total_courant_usd, 2)
                lignes_u.append({
                    "Date": pd.Timestamp(d_cle),
                    "date": d_cle.isoformat(),
                    "patrimoine_investi_usd": round(inv_u, 2),
                    "patrimoine_total_usd": round(tot_u, 2),
                    "precaution_usd": round(max(tot_u - inv_u, 0.0), 2),
                    "courant_usd": 0.0,
                    "capital_investi_usd": None,
                    "patrimoine_investi_eur": round(inv_e, 2),
                    "patrimoine_total_eur": round(tot_e, 2),
                    "precaution_eur": round(max(tot_e - inv_e, 0.0), 2),
                    "courant_eur": 0.0,
                    "cours_or_usd": float(co) if pd.notna(co) else None,
                    "equivalent_or_oz": float(oz) if pd.notna(oz) else None,
                })

        df_out = pd.DataFrame(lignes_u)
        ctx.snapshots = df_out
    elif not snaps.empty:
        # Repli si `Projections` n'est pas accessible : on déduit l'USD depuis
        # `equivalent_or_oz * cours_or_usd` ou `patrimoine_investi_eur * taux`.
        inv_u_list = []
        tot_u_list = []
        prec_u_list = []
        for _, sr in snaps.iterrows():
            inv_e = float(sr.get("patrimoine_investi_eur") or 0.0)
            tot_e = float(sr.get("patrimoine_total_eur") or inv_e)
            oz = sr.get("equivalent_or_oz")
            co = sr.get("cours_or_usd")
            if pd.notna(oz) and pd.notna(co) and float(oz) > 0 and float(co) > 0:
                inv_u = float(oz) * float(co)
                ratio = inv_u / inv_e if inv_e > 0 else taux
                tot_u = tot_e * ratio
            else:
                inv_u = inv_e * taux
                tot_u = tot_e * taux
            inv_u_list.append(round(inv_u, 2))
            tot_u_list.append(round(tot_u, 2))
            prec_u_list.append(round(max(tot_u - inv_u, 0.0), 2))
        snaps["patrimoine_investi_usd"] = inv_u_list
        snaps["patrimoine_total_usd"] = tot_u_list
        snaps["precaution_usd"] = prec_u_list
        ctx.snapshots = snaps

    # Pour la référence la plus récente, pf2_snapshots fait foi : ne pas
    # associer ses euros aux dollars d'une autre valorisation de Projections.
    # L'historique v1 et son capital investi restent inchangés.
    if not snaps.empty and not ctx.snapshots.empty:
        dates_brutes = _parser_dates(snaps["Date"])
        dernier = dates_brutes.max()
        if pd.notna(dernier) and dernier == _parser_dates(ctx.snapshots["Date"]).max():
            sr = snaps.loc[dates_brutes == dernier].iloc[-1]
            inv_e = float(sr.get("patrimoine_investi_eur") or 0.0)
            tot_e = float(sr.get("patrimoine_total_eur") or inv_e)
            oz, co = sr.get("equivalent_or_oz"), sr.get("cours_or_usd")
            inv_u = float(oz) * float(co) if pd.notna(oz) and pd.notna(co) and float(oz) > 0 and float(co) > 0 else inv_e * taux
            ratio = inv_u / inv_e if inv_e > 0 else taux
            idx = ctx.snapshots.index[_parser_dates(ctx.snapshots["Date"]) == dernier][-1]
            for cle, valeur in {
                "patrimoine_investi_eur": inv_e, "patrimoine_total_eur": tot_e,
                "patrimoine_investi_usd": inv_u, "patrimoine_total_usd": tot_e * ratio,
                "precaution_eur": float(sr.get("precaution_eur") or 0.0),
                "courant_eur": float(sr.get("courant_eur") or 0.0),
                "precaution_usd": float(sr.get("precaution_eur") or 0.0) * ratio,
                "courant_usd": float(sr.get("courant_eur") or 0.0) * ratio,
                "equivalent_or_oz": oz, "cours_or_usd": co,
            }.items():
                ctx.snapshots.at[idx, cle] = round(valeur, 2) if pd.notna(valeur) and cle.endswith(("_eur", "_usd")) else valeur

    if not ctx.snapshots.empty:
        ctx.snapshots = ctx.snapshots.sort_values("Date", kind="stable").reset_index(drop=True)

    # Un snapshot daté d'aujourd'hui reste la référence de la nuit. Le point
    # live est distinct, daté du jour réel (pas de la dernière date historique).
    # La table ne porte pas d'heure : aucun flux intrajournalier n'est imputé
    # une seconde fois quand le snapshot et le live ont la même date.
    if not ctx.snapshots.empty and ctx.total_investi_usd > 0:
        jour = pd.Timestamp(dt.date.today())
        if pd.to_datetime(ctx.snapshots["Date"]).max() <= jour:
            live = {
                "Date": jour, "date": jour.date().isoformat(), "_live": True,
                "patrimoine_investi_usd": round(ctx.total_investi_usd, 2),
                "patrimoine_investi_eur": round(ctx.total_investi_eur, 2),
                "patrimoine_total_usd": round(ctx.patrimoine_total_usd, 2),
                "patrimoine_total_eur": round(ctx.patrimoine_total_eur, 2),
                "precaution_usd": round(ctx.total_precaution_usd, 2),
                "precaution_eur": round(ctx.total_precaution_eur, 2),
                "courant_usd": round(ctx.total_courant_usd, 2),
                "courant_eur": round(ctx.total_courant_eur, 2),
                "equivalent_or_oz": ctx.equivalent_or_oz,
                "cours_or_usd": ctx.cours_or,
            }
            live = {k: v for k, v in live.items() if v is not None}
            ctx.snapshots = pd.concat([ctx.snapshots, pd.DataFrame([live])], ignore_index=True)

    # --- 3. Propagation complète de `capital_investi_usd` et `capital_investi_eur` ---
    # Garantit qu'aucune date (ni le 02/10/2026 où la v1 a écrit 0, ni les
    # snapshots écrits par le robot v2 dans `pf2_snapshots`) n'affiche « — ».
    if ctx.snapshots is not None and not ctx.snapshots.empty and "Date" in ctx.snapshots.columns:
        df_s = ctx.snapshots.copy()
        dates_s = [pd.Timestamp(d).date() for d in _parser_dates(df_s["Date"])]
        col_ap_u = "montant_usd" if (ctx.apports is not None and "montant_usd" in getattr(ctx.apports, "columns", [])) else "montant_eur"
        flux_u_map = flux_par_date(ctx.apports, col_ap_u)
        flux_ap_u = metrics.flux_par_periode(dates_s, flux_u_map) if len(dates_s) >= 2 else [0.0] * len(dates_s)

        cap_existant = (
            pd.to_numeric(df_s["capital_investi_usd"], errors="coerce").where(lambda s: s > 0)
            if "capital_investi_usd" in df_s.columns
            else pd.Series([None] * len(df_s), index=df_s.index)
        )

        cap_u_final: list[float | None] = []
        if cap_existant.notna().any():
            prev_c: float | None = None
            for i in range(len(df_s)):
                val_c = cap_existant.iloc[i]
                if pd.notna(val_c) and float(val_c) > 0:
                    prev_c = round(float(val_c), 2)
                    cap_u_final.append(prev_c)
                elif prev_c is not None:
                    f_i = float(flux_ap_u[i]) if i < len(flux_ap_u) else 0.0
                    prev_c = round(prev_c + f_i, 2)
                    cap_u_final.append(prev_c)
                else:
                    cap_u_final.append(None)
        elif flux_u_map:
            for d_i in dates_s:
                cum_u = sum(m for d_ap, m in flux_u_map.items() if d_ap <= d_i)
                cap_u_final.append(round(cum_u, 2) if cum_u > 0 else None)
        else:
            cap_u_final = [None] * len(df_s)

        cap_e_final: list[float | None] = []
        for i, (_, r_s) in enumerate(df_s.iterrows()):
            cu = cap_u_final[i]
            if cu is None or cu <= 0:
                cap_e_final.append(None)
            else:
                inv_u_i = float(r_s.get("patrimoine_investi_usd") or 0.0)
                inv_e_i = float(r_s.get("patrimoine_investi_eur") or 0.0)
                ratio_i = (inv_u_i / inv_e_i) if (inv_u_i > 0 and inv_e_i > 0) else taux
                cap_e_final.append(round(cu / ratio_i, 2))

        df_s["capital_investi_usd"] = cap_u_final
        df_s["capital_investi_eur"] = cap_e_final
        ctx.snapshots = df_s


def _derniere_reference(ctx: "Contexte") -> tuple[dt.date | None, object]:
    """Date et horodatage d'enregistrement du dernier snapshot (hors direct).

    Le point `_live` est la valorisation du moment : il ne peut pas servir de
    reference, sinon la progression comparerait le direct a lui-meme.
    """
    snaps = getattr(ctx, "snapshots", None)
    if snaps is None or getattr(snaps, "empty", True):
        return None, None
    vus = snaps
    if "_live" in getattr(vus, "columns", []):
        vus = vus[~vus["_live"].eq(True)]
    if vus.empty:
        return None, None

    ligne = vus.iloc[-1]
    date_ref = None
    brut = ligne.get("Date", ligne.get("date"))
    if brut is not None:
        quand = pd.to_datetime(brut, errors="coerce")
        if pd.notna(quand):
            date_ref = quand.date()
    cree = ligne.get("cree_le") if "cree_le" in vus.columns else None
    if cree is not None and pd.isna(cree):
        cree = None
    return date_ref, cree


def progression_periode(
    ctx: "Contexte",
    mode_periode: str = "Progression journalière",
    perimetre: str = "Portefeuille investi",
    date_deb: dt.date | None = None,
    date_fin: dt.date | None = None,
) -> dict:
    """Calcule la série graphique et les indicateurs de progression sur la période choisie.

    Utilise `serie_performance(ctx)` pour garantir la cohérence absolue des flux
    d'apports (`capital_investi_usd`) et du TWR avec la page Performance.
    """
    df_base, _, flux_base = serie_performance(ctx)
    if df_base.empty:
        return {"vide": True}

    df_p = df_base.copy()
    df_p["date_dt"] = pd.to_datetime(df_p["Date"], errors="coerce")
    df_p["_flux_usd"] = flux_base
    df_p = df_p.dropna(subset=["date_dt"]).sort_values("date_dt", kind="stable").reset_index(drop=True)
    # Les achats/ventes de titres sont des transferts internes : ils comptent
    # dans le périmètre investi, jamais dans le patrimoine total.
    if perimetre != "Patrimoine total" and not df_p.empty:
        df_p["_flux_usd"] = _ajouter_flux_instruments(
            [float(f) for f in df_p["_flux_usd"]], flux_instruments_final_usd(ctx)
        )

    col_val_usd = (
        "patrimoine_investi_usd"
        if perimetre == "Portefeuille investi" or "patrimoine_total_usd" not in df_p.columns
        else "patrimoine_total_usd"
    )
    if col_val_usd not in df_p.columns:
        col_val_usd = "patrimoine_investi_eur"

    d_min = df_p["date_dt"].min().date()
    d_max = df_p["date_dt"].max().date()
    label_periode = mode_periode

    if mode_periode == "Progression journalière":
        # Dernier snapshot conservé -> point en direct, même si les dates sont identiques.
        df_graphe = df_p.tail(min(len(df_p), 90)).copy()
        df_calc = df_p.tail(min(len(df_p), 2)).copy()
    elif mode_periode == "Progression mensuelle":
        df_p["_ym"] = df_p["date_dt"].dt.to_period("M")
        flux_mensuel = df_p.groupby("_ym")["_flux_usd"].sum()
        df_graphe = df_p.groupby("_ym", as_index=False).last().sort_values("date_dt", kind="stable").reset_index(drop=True)
        df_graphe["_flux_usd"] = [float(flux_mensuel.get(ym, 0.0)) for ym in df_graphe["_ym"]]
        df_calc = df_graphe.tail(min(len(df_graphe), 2)).copy()
    elif mode_periode == "Depuis le début du mois":
        debut_mois = pd.Timestamp(d_max.year, d_max.month, 1)
        avant = df_p[df_p["date_dt"] < debut_mois]
        dans = df_p[df_p["date_dt"] >= debut_mois]
        df_graphe = pd.concat([avant.tail(1), dans], ignore_index=True) if not avant.empty else dans.copy()
        df_calc = df_graphe.copy()
    elif mode_periode == "Depuis le début de l'année":
        debut_an = pd.Timestamp(d_max.year, 1, 1)
        avant = df_p[df_p["date_dt"] < debut_an]
        dans = df_p[df_p["date_dt"] >= debut_an]
        df_graphe = pd.concat([avant.tail(1), dans], ignore_index=True) if not avant.empty else dans.copy()
        df_calc = df_graphe.copy()
    elif mode_periode == "Depuis 1 an":
        un_an = pd.Timestamp(d_max - dt.timedelta(days=365))
        avant = df_p[df_p["date_dt"] <= un_an]
        dans = df_p[df_p["date_dt"] > un_an]
        df_graphe = pd.concat([avant.tail(1), dans], ignore_index=True) if not avant.empty else dans.copy()
        df_calc = df_graphe.copy()
    elif mode_periode == "Période choisie":
        d_deb = date_deb or max(d_min, d_max - dt.timedelta(days=30))
        d_fin = date_fin or d_max
        ts_deb = pd.Timestamp(d_deb)
        ts_fin = pd.Timestamp(d_fin)
        avant = df_p[df_p["date_dt"] <= ts_deb]
        dans = df_p[(df_p["date_dt"] > ts_deb) & (df_p["date_dt"] <= ts_fin)]
        df_graphe = pd.concat([avant.tail(1), dans], ignore_index=True) if not avant.empty else df_p[df_p["date_dt"] <= ts_fin].copy()
        df_calc = df_graphe.copy()
    else:  # Depuis le début
        df_graphe = df_p.copy()
        df_calc = df_p.copy()

    if len(df_calc) >= 2:
        d0_str = df_calc["date_dt"].iloc[0].strftime("%d/%m/%Y")
        d1_str = df_calc["date_dt"].iloc[-1].strftime("%d/%m/%Y")
        prefixe_lbl = "Depuis le dernier enregistrement" if mode_periode == "Progression journalière" else mode_periode
        label_periode = f"{prefixe_lbl} ({d0_str} → {d1_str})"

        valeurs_c = [float(v) for v in df_calc[col_val_usd].tolist()]
        flux_c = [0.0] + [float(f) for f in df_calc["_flux_usd"].iloc[1:].tolist()]

        # Achats et ventes de titres enregistres apres la derniere reference :
        # transferts internes. Ils comptent dans le perimetre investi, jamais
        # dans le patrimoine total — deplacer de l'argent du compte courant vers
        # les titres ne rend pas plus riche. Sans cela, un achat enregistre
        # apres le snapshot etait compte comme un gain de marche (artefact du
        # 07/10/2026 : +2,85 % au lieu de -0,38 %).
        if perimetre == "Portefeuille investi":
            date_ref, cree_ref = _derniere_reference(ctx)
            transfert = flux_titres_internes(
                getattr(ctx, "transactions", None), date_ref, cree_ref
            )
            if transfert:
                flux_c[-1] = flux_c[-1] + transfert

        v_debut_usd = valeurs_c[0]
        v_fin_usd = valeurs_c[-1]
        delta_val_usd = v_fin_usd - v_debut_usd
        apports_periode_usd = sum(flux_c[1:])
        gain_marche_usd = delta_val_usd - apports_periode_usd
        twr_per = metrics.twr_depuis(valeurs_c, flux_c)
        pct_brut = (delta_val_usd / v_debut_usd) if v_debut_usd > 0 else 0.0
    else:
        v_debut_usd = float(df_p[col_val_usd].iloc[-1])
        v_fin_usd = v_debut_usd
        delta_val_usd = 0.0
        apports_periode_usd = 0.0
        gain_marche_usd = 0.0
        twr_per = 0.0
        pct_brut = 0.0

    taux = ctx.taux_eur_usd if ctx.taux_eur_usd else 1.0
    return {
        "vide": False,
        "df_graphe": df_graphe,
        "col_val_usd": col_val_usd,
        "d_min": d_min,
        "d_max": d_max,
        "label_periode": label_periode,
        "v_debut_usd": v_debut_usd,
        "v_fin_usd": v_fin_usd,
        "delta_val_usd": delta_val_usd,
        "delta_val_eur": delta_val_usd / taux,
        "apports_periode_usd": apports_periode_usd,
        "apports_periode_eur": apports_periode_usd / taux,
        "gain_marche_usd": gain_marche_usd,
        "gain_marche_eur": gain_marche_usd / taux,
        "twr_per": twr_per,
        "pct_brut": pct_brut,
    }


def inflation_dict(ctx: Contexte) -> dict[int, float]:
    return _inflation_par_annee(ctx.inflation)


def vider_cache() -> None:
    charger.clear()
    prices.vider_cache()
    fx.vider_cache()
